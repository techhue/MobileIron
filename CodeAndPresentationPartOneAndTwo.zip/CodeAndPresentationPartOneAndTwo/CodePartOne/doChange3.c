#include <stdio.h>
//Choices
//:  A   B    C    D    E    F
//:  20  30   80  CTE  RTE  NoT
//V           10        
//V1 9                       

void doChange(int *ptr) {
	int b = 30;
	ptr = &b;
	b = b + 50;
	*ptr = b;
}

int main() {
	int a = 20;
	int *ptr = &a;

	doChange(ptr);
	printf("\nValue is: %d", 
		*ptr);
}
