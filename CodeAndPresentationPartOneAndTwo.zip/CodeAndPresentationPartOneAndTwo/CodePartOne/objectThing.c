#include <stdio.h>

typedef struct point_type {
	float x;
	float y;
	int (*dance) ();        	
}Point;

int doBhangra() {
	printf("Balleee Baleeeee");
	return 0;
}

int main() {
	int a = 10, b = 20;
	Point origin = { 0, 0 };
	origin.dance = doBhangra;
	
	printf("\n %f %f", origin.x, origin.y);
	origin.dance();
}
