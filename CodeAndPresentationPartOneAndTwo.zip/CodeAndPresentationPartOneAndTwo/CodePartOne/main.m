
#import <Foundation/Foundation.h>


void voidType() {
	NSLog(@"Hello World!");
}

void intType() {
	BOOL isBool = YES;
	int i = -11;

	if(i) {  //if (isBool) {
		printf("Hi");
	} else {
		
	}
}


void intType() {

        BOOL isBool = YES;
        NSLog(@"%d", isBool);
        NSLog(@"%@", isBool ? @"YES" : @"NO");

        char aChar = 'a';
        unsigned char anUnsignedChar = 255;
        NSLog(@"The letter %c is ASCII number %hhd", aChar, aChar);
        NSLog(@"%hhu", anUnsignedChar);   

        short aShort = -32768;
        unsigned short anUnsignedShort = 65535;
        NSLog(@"%hd", aShort);
        NSLog(@"%hu", anUnsignedShort);

        int anInt = -2147483648;
        unsigned int anUnsignedInt = 4294967295;
        NSLog(@"%d", anInt);
        NSLog(@"%u", anUnsignedInt);

        long aLong = -92233720;
        unsigned long anUnsignedLong = 1844674407;
        //long aLong = -9223372036854775808;
        //unsigned long anUnsignedLong = 18446744073709551615;
        NSLog(@"%ld", aLong);
        NSLog(@"%lu", anUnsignedLong);


        long long aLongLong = -92233720;
        unsigned long long anUnsignedLongLong = 1844674407;
        //long long aLongLong = -9223372036854775808;
        //unsigned long long anUnsignedLongLong = 18446744073709551615;
        NSLog(@"%lld", aLongLong);
        NSLog(@"%llu", anUnsignedLongLong);

}


typedef char int8;
typedef unsinged char uint8;


/*
“to declare a variable that stores a specific number of bytes”
“The int<n>_t data types allow you to represent signed and unsigned 
integers that are exactly 1, 2, 4, or 8 bytes,
 and the int_least<n>_t variants let you constrain the minimum size
  of a variable without specifying an 
 exact number of bytes. In addition, intmax_t is an alias for the 
 largest integer type that the system can handle.”
*/


void fixedWidthIntegers() {

        // Exact integer types
        int8_t aOneByteInt = 127;
        uint8_t aOneByteUnsignedInt = 255;
        int16_t aTwoByteInt = 32767;
        uint16_t aTwoByteUnsignedInt = 65535;

        int32_t aFourByteInt = 2147483647;
        uint32_t aFourByteUnsignedInt = 4294967295;
        int64_t anEightByteInt = 9223372036854775807;
        //uint64_t anEightByteUnsignedInt = 18446744073709551615;

        // Minimum integer types
        int_least8_t aTinyInt = 127;
        uint_least8_t aTinyUnsignedInt = 255;
        int_least16_t aMediumInt = 32767;
        uint_least16_t aMediumUnsignedInt = 65535;
        int_least32_t aNormalInt = 2147483647;
        uint_least32_t aNormalUnsignedInt = 4294967295;
        int_least64_t aBigInt = 9223372036854775807;
        //uint_least64_t aBigUnsignedInt = 18446744073709551615;

        // The largest supported integer type
        intmax_t theBiggestInt = 9223372036854775807;
        //uintmax_t theBiggestUnsignedInt = 18446744073709551615;

}
// “ The only guarantee is that short <= int <= long <= long long”

void floatingPointType() {

        // Single precision floating-point
        float aFloat = -21.09f;
        NSLog(@"%f", aFloat);
        NSLog(@"%8.2f", aFloat);

        // Double precision floating-point
        double aDouble = -21.09;
        NSLog(@"%8.2f", aDouble);

        NSLog(@"%e", aDouble);

        // Extended precision floating-point
        long double aLongDouble = -21.09e8L;
        NSLog(@"%Lf", aLongDouble);
        NSLog(@"%Le", aLongDouble);
}

/*
“ Instead of forcing you to guess, the sizeof() function returns a 
special data type called size_t.”

“The size_t type is dedicated solely to representing memory-related values, 
and  it is guaranteed to be able to store the maximum size of an array. 
Aside from being the return type for sizeof() and other memory utilities, t
his makes size_t an appropriate data type for storing the indices of very 
large arrays. As with any other type, you can pass it to sizeof() to get 
its exact size at runtime, ”

“If your Objective-C programs interact with a lot of C libraries, you’re likely to encounter 
the following application of sizeof():”

“size_t numberOfElements = sizeof(anArray)/sizeof(anArray[0]);

This is the canonical way to determine the number of elements in a 
primitive C array. It simply divides the size of the array, 
sizeof(anArray), by the size of each element, sizeof(anArray[0]).
*/

void deteminingSizeType() {

        NSLog(@"Size of char: %zu", sizeof(char));   // This will always be 1
        NSLog(@"Size of short: %zu", sizeof(short));
        NSLog(@"Size of int: %zu", sizeof(int));
        NSLog(@"Size of long: %zu", sizeof(long));
        NSLog(@"Size of long long: %zu", sizeof(long long));
        NSLog(@"Size of float: %zu", sizeof(float));
        NSLog(@"Size of double: %zu", sizeof(double));
        NSLog(@"Size of size_t: %zu", sizeof(size_t));


        /*
        This is the canonical way to determine the number of elements in a 
        primitive C array. It simply divides the size of the array, 
        sizeof(anArray), by the size of each element, sizeof(anArray[0]).
        */
        int anArray[10];
        size_t numberOfElements = sizeof(anArray)/sizeof(anArray[0]);
}

/*
The SIZE_MAX macro defines the maximum value that can be stored in a size_t variable.
*/

void limitMacros() {

        NSLog(@"Smallest signed char: %d", SCHAR_MIN);
        NSLog(@"Largest signed char: %d", SCHAR_MAX);
        NSLog(@"Largest unsigned char: %u", UCHAR_MAX);

        NSLog(@"Smallest signed short: %d", SHRT_MIN);
        NSLog(@"Largest signed short: %d", SHRT_MAX);

        NSLog(@"Largest unsigned short: %u", USHRT_MAX);
        NSLog(@"Smallest signed int: %d", INT_MIN);
        NSLog(@"Largest signed int: %d", INT_MAX);
        NSLog(@"Largest unsigned int: %u", UINT_MAX);

        NSLog(@"Smallest signed long: %ld", LONG_MIN);
        NSLog(@"Largest signed long: %ld", LONG_MAX);
        NSLog(@"Largest unsigned long: %lu", ULONG_MAX);

        NSLog(@"Smallest signed long long: %lld", LLONG_MIN);
        NSLog(@"Largest signed long long: %lld", LLONG_MAX);
        NSLog(@"Largest unsigned long long: %llu", ULLONG_MAX);

        NSLog(@"Smallest float: %e", FLT_MIN);
        NSLog(@"Largest float: %e", FLT_MAX);
        NSLog(@"Smallest double: %e", DBL_MIN);
        NSLog(@"Largest double: %e", DBL_MAX);

        NSLog(@"Largest possible array index: %llu", SIZE_MAX);
}


/*
“the answer is quite simple: use int’s unless you have a compelling 
reason not to.

“Traditionally, an int is defined to be the native word size of the 
underlying architecture, so it’s (generally) the most efficient integer type. 
The only reason to use a short is when you want to reduce the memory footprint 
of very large arrays (e.g., an OpenGL index buffer). The long types should 
only be used when you need to store values that don’t fit into an int.”
*/

void floatingPointEquality() {

        NSLog(@"%.17f", 4.2 - 4.1); // 0.10000000000000053
        if (4.2 - 4.1 == .1) {
            NSLog(@"This math is perfect!");
        } else {
            // You'll see this message
            NSLog(@"This math is just a tiny bit off...");
        }
}




/*
int main() {
	voidType();
}


