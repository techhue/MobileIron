#include <stdio.h>
#include <stdlib.h>

//Choices
//Que:  A   B    C    D    E    F
//Ans:  20  30   80  CTE  RTE  NoT
//Vote           9  
//Vote1 3        3               4 
                           
int * doChange(int *ptr) {
	int b = 30;
	ptr = (int *) malloc( sizeof(int) );
	ptr = &b;
	b = b + 50;
	return ptr;
}

int main() {
	int a = 20;
	int *ptr = &a;

	ptr = doChange(ptr);
	printf("\nValue is: %d", 
		*ptr);
}
