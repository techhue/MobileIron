
class Human {



}


