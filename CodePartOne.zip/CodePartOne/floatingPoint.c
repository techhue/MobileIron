#include <stdio.h>

//A. CTE  B. RTE  C. Equal D. Not Equal E. NoT


int main() {
	float f = 3.0000;
	int i = 3;

	if ( f== i ) {
		printf("\nEqual");
	} else {
		printf("\nNot Equal");
	}

	float exp = 10.0;

	switch(exp) {
	case 10:


	case 20:
	
	}

	int i = 10, j = 3;

	float f = i / j;
}


