#import <Foundation/Foundation.h>

@interface XYZPerson: NSObject

- (void) sayHello;

@end

@implementation XYZPerson 

- (void) sayHello {
	NSLog(@"Hello World!");
}

@end

int main() {
	XYZPerson *ram = [[XYZPerson alloc] init];
	[ram sayHello];
}
