
#include "XYZPerson.h"

int main() {
	

}
