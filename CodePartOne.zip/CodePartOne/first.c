#include<stdio.h>


/*
What is a Data Type? - REJECTED
_________________________________
1. To represent the data ???
2. To store particular /kind/-Same Set of Data,  of data???
3. How we are /storing/ the data in memory ???
4. Identifier/Variable of the data
5. Way to store data 
6. Memory Location
7. To define kind of data, defines particular type of data
8. Characteristics: What kind of data?
9. To store similar(type) kind of data
10.

What is a Data Type? - ACCEPTED IDEAS
_________________________________
1. Defines Range
2.


// Natural is a Data Type...

True/False

N = 
R = {1, 2, 3, ... }
Operations = { +, -, *, / }

// int is an integer(mathmatics)
// TRUE | FALSE


// Write VALID sum function in C/C++
// Define following function
// int error = 0;
// int sum(int a, int b, int *Error) {
//   RETURN VALID sum or Error...

*/

//BAD Code, NonTestable

int sum(int a, int b) {
	int c;
	c = a + b;
	return c;

	//return a + b;
}

int result = sum(30000, 30000);

//ASSERT(result == 60000);
//ASSERT(-32768 <= result <= 32767)


int main() {
	unsigned char ch = 100;
	char chnew = 90;
	for( ch = 0 ; ch < 255 ; ch++) {
		printf("Hello %d %c \n ", ch, ch);
	} 
	
	if (ch && chnew) {
		printf("Ding");
	} else {
		printf("Dong");
	}
}


