#include <stdio.h>
//Choices
//Que:  A   B    C    D    E    F
//Ans:  20  30   80  CTE  RTE  NoT
//Vote  4   2    3              1 
    
void doChange(int *ptr) {
	int b = 30;
	ptr = &b;
	b = b + 50;
}

int main() {
	int a = 20;
	int *ptr = &a;

	doChange(ptr);
	printf("\nValue is: %d", *ptr);
}
