
#include <stdio.h>

//int fun();

int fun() {
	printf("Funny Fun..");
	return 0;
}

int main() { 
	fun();
}

